package student;


 public class Student{
 
	 private int id;
	    private String name;
	    private int grade;
	    private int feesPaid;
	    private int feesTotal;
	    
	    public Student(int id, String name,int grade){
	        this.feesPaid=0;
	        this.feesTotal=30000;
	        this.id=id;
	        this.name=name;
	        this.grade=grade;

	    }
	    
	    public Student() {
			// TODO Auto-generated constructor stub
		}

		public int getId() {
	        return id;
	    }

	    public String getName() {
	        return name;
	    }
	    
	    public int getGrade() {
	        return grade;
	    }
	    
	    public int getFeesPaid() {
	        return feesPaid;
	    }

	    public int getFeesTotal() {
	        return feesTotal;
	    }
	    
	    public String toString() {
	        return "Student's name is: "+name+" Student's id is : "+id+" Student's grade is :"+grade+
	                " Total fees paid is "+ feesPaid;
	    }
	    
	   
	    
	    public void payFees(int fees){
	        feesPaid+=fees;
	        }
	    
	    public int getRemainingFees(){
	        return feesTotal-feesPaid;
	    }
	    
	    public static void main(String[] args) {
			Student student1 = new Student(1,"Ranjita",16);
			Student student2 = new Student(2,"Arpita", 12);
			Student student3 = new Student(3,"Ruchita",34);
		
			student1.payFees(5000);
	        student2.payFees(6000);
	        student3.payFees(1200);
		    System.out.println(student1);
		    //System.out.println(student2);
		    //System.out.println(student3);
			
		}
	    
	    
 }